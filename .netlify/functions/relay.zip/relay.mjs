
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// src/prompt.ts
var DEFAULT_MODEL = "nvidia/nemotron-3-super-120b-a12b";
var FAST_MODEL = "nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B";
var SYSTEM = [
  "You are NOAI, a private assistant. You only see the passages below, chosen and redacted on the owner's device.",
  "Answer from the passages only. If they do not contain the answer, say so plainly.",
  "Values like [EMAIL_1] or [PHONE_2] are placeholders for redacted data. Use them exactly as written, never guess what they stand for.",
  "Be brief. Cite passages as [P1], [P2].",
  'If the question itself tells you a new lasting fact about the owner (a new doctor, a changed date, a new number), end with one extra line of the form "REMEMBER: <the fact as one sentence>", keeping any placeholders exactly as written. Never add that line for facts already in the passages, and never for anything you inferred.'
].join(" ");

// relay/core.mjs
var UPSTREAM = "https://api.tokenfactory.nebius.com/v1/chat/completions";
var MAX_BODY_BYTES = 8e3;
var MAX_TOKENS = 4096;
var MODELS = /* @__PURE__ */ new Set([DEFAULT_MODEL, FAST_MODEL]);
var WINDOW_MS = 10 * 60 * 1e3;
var PER_WINDOW = 30;
var hits = /* @__PURE__ */ new Map();
function limited(client, now = Date.now()) {
  const recent = (hits.get(client) ?? []).filter((t) => now - t < WINDOW_MS);
  recent.push(now);
  hits.set(client, recent);
  if (hits.size > 5e3) hits.clear();
  return recent.length > PER_WINDOW;
}
var reply = (status, error) => new Response(JSON.stringify({ error }), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
function refuse(body) {
  let j;
  try {
    j = JSON.parse(body);
  } catch {
    return "Not JSON.";
  }
  if (!MODELS.has(j.model)) return "Model not allowed.";
  if (!Number.isInteger(j.max_tokens) || j.max_tokens < 1 || j.max_tokens > MAX_TOKENS) return "max_tokens out of range.";
  const m = j.messages;
  if (!Array.isArray(m) || m.length !== 2) return "Expected exactly a system and a user message.";
  if (m[0]?.role !== "system" || m[0]?.content !== SYSTEM) return "Not a NOAI disclosure.";
  if (m[1]?.role !== "user" || typeof m[1]?.content !== "string" || !m[1].content.startsWith("PASSAGES\n")) return "Not a NOAI disclosure.";
  const allowed = /* @__PURE__ */ new Set(["model", "max_tokens", "temperature", "messages"]);
  if (Object.keys(j).some((k) => !allowed.has(k))) return "Unexpected field.";
  return null;
}
async function relay(request, env, fetchImpl = fetch) {
  if (request.method !== "POST") return reply(405, "POST only.");
  const origins = (env.NOAI_ALLOWED_ORIGINS ?? "").split(",").map((s) => s.trim()).filter(Boolean);
  const origin = request.headers.get("origin");
  if (origins.length && !origins.includes(origin ?? "")) return reply(403, "Origin not allowed.");
  if (!env.NEBIUS_API_KEY) return reply(503, "The relay has no key configured.");
  const client = request.headers.get("x-nf-client-connection-ip") ?? request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
  if (limited(client)) return reply(429, "Too many requests. Try again in a few minutes.");
  const bytes = new Uint8Array(await request.arrayBuffer());
  if (bytes.length > MAX_BODY_BYTES) return reply(413, `Over the ${MAX_BODY_BYTES} byte ceiling.`);
  const body = new TextDecoder().decode(bytes);
  const why = refuse(body);
  if (why) return reply(400, why);
  const upstream = await fetchImpl(UPSTREAM, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${env.NEBIUS_API_KEY}` },
    body: bytes
  });
  return new Response(await upstream.text(), {
    status: upstream.status,
    headers: { "content-type": "application/json", "cache-control": "no-store" }
  });
}

// netlify/functions/relay.mjs
var relay_default = (request) => relay(request, process.env);
var config = { path: "/api/chat" };
export {
  config,
  relay_default as default
};
